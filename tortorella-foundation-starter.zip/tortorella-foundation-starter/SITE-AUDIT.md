# Tortorella Family Foundation Website Audit

Reviewed: July 19, 2026  
Current site: https://www.tortorellafoundation.org/

## Executive summary

The foundation has a meaningful mission, recognizable programs, a long history of community relationships, and a substantial body of stories. The current website hides those strengths beneath dated presentation, dense pages, inconsistent content, and weak conversion paths.

The highest-impact redesign opportunity is not decorative. It is structural: explain the mission immediately, group the work into a few clear program areas, show credible examples of impact, and make donating or contacting the foundation obvious and trustworthy.

## Highest-priority issues

### 1. The homepage does not establish a clear visitor journey

The homepage moves from a broad foundation introduction to Bear's Angels, literacy, a long news feed, a long grant-recipient list, and a lengthy mission statement. Important content is present, but there is no clear sequence of “who we are → what we do → proof → how to help.”

**Improve it by:**
- Opening with one plain-language mission statement and two primary calls to action.
- Presenting three program areas in a consistent card system.
- Showing a small number of recent stories instead of an extended feed.
- Moving the full partner directory and long mission copy to dedicated pages.

### 2. Navigation is crowded and mixes different types of destinations

The top navigation includes nested About pages, a separate external literacy domain, a Bear's Angels menu with subpages, news, organizations, and contact. Program names, content categories, and external links all compete at the same level.

**Improve it by:**
- Using five or six top-level items: About, Our Work, Partners, News, Contact, Donate.
- Grouping Bear's Angels and literacy under Our Work.
- Treating the children's learning website as a clearly labeled external resource, not a primary navigation branch.
- Adding a persistent, high-contrast Donate button.

### 3. The donation path lacks clarity and trust signals

Donation appears as a small PayPal-style image on internal pages rather than a visible, consistent action. The site does not prominently explain how gifts are used, whether donations are tax deductible, what financial documents are available, or what a donor can expect.

**Improve it by:**
- Creating a dedicated giving page with a verified donation processor.
- Adding brief impact examples and allocation language.
- Publishing EIN/tax status, annual reports, Form 990 links, privacy terms, and receipt expectations where appropriate.
- Using one consistent “Donate” action in the header and major calls to action.

### 4. Content quality issues reduce credibility

There are visible typos, spacing problems, punctuation inconsistencies, and awkward phrases across core pages. Examples include “proifits,” “polices,” “whereever,” “it’s website,” “care,foster,” and “Hockey & Hoiunds.” Inner pages also repeat generic modules such as “Latest News” whether or not they help the page's goal.

**Improve it by:**
- Running a full editorial pass before redesign migration.
- Establishing a short style guide for names, punctuation, dates, and program capitalization.
- Assigning one person to approve final site copy.
- Removing repeated sidebar content that does not help the visitor complete the page's task.

### 5. Partner information looks stale and is hard to trust

The organizations page is essentially a long text list, and many links route through the Internet Archive rather than current official websites. The homepage separately shows a 2025 grant-recipient list. Visitors cannot easily tell which organizations are current, when they were funded, where they operate, or what the grant supported.

**Improve it by:**
- Building a current partner directory with organization name, location, focus, year supported, short grant summary, and verified link.
- Separating current grant recipients from historical partners.
- Reviewing every external link at least twice a year.
- Adding filters only if the directory becomes large enough to need them.

### 6. Accessibility and semantic structure need attention

The parsed site markup includes many images labeled only “Image,” generic “Learn more...” links, duplicated or weak headings, and social icons without meaningful text in the visible structure. The Contact page contains both “Contact” and “contact,” and its CAPTCHA output appears as an unexplained delta symbol.

**Improve it by:**
- Writing descriptive alternative text for meaningful images and empty alt text for decorative images.
- Replacing generic links with descriptive labels.
- Maintaining one H1 per page and logical H2/H3 nesting.
- Ensuring keyboard navigation, visible focus styles, adequate contrast, labeled form fields, clear errors, and reduced-motion support.
- Testing with Lighthouse, axe, keyboard-only navigation, and at least one screen reader.

### 7. Mobile readability and visual hierarchy should be rebuilt, not patched

The current content density, lengthy navigation, repeated side modules, and long unstructured lists are especially difficult on smaller screens. Even responsive behavior cannot solve the underlying hierarchy problem.

**Improve it by:**
- Designing mobile-first sections with short headings and comfortable text widths.
- Replacing multi-level navigation with a simple menu.
- Using cards, accordions, or categorized lists for large content sets.
- Keeping tap targets at least 44 by 44 pixels and avoiding tiny linked images.

### 8. The visual system feels dated and inconsistent

The current site combines multiple logo styles, small images, old blog presentation, text-heavy sidebars, generic buttons, and little spacing rhythm. It does not visually express the warmth and hands-on nature of the mission.

**Improve it by:**
- Establishing a restrained palette, type scale, spacing system, button styles, card styles, and image treatment.
- Using real photography at larger sizes.
- Giving Bear's Angels and the literacy program distinct visual moments within one shared foundation brand.
- Avoiding novelty effects that compete with the mission.

### 9. News content needs stronger governance

The news section mixes adoption events, pet-safety articles, grant announcements, foundation news, and hockey career updates. That can be appropriate, but categories and relevance are not clear.

**Improve it by:**
- Defining three or four content categories.
- Adding summaries, meaningful featured images, and clear publication dates.
- Separating foundation impact stories from external resource reposts.
- Establishing an archive policy and removing or redirecting obsolete event posts.

### 10. Technical and search fundamentals should be modernized

The footer still displays a 2020 copyright year. Page paths such as `/contact-2/` suggest legacy content management. The site should be reviewed for metadata, redirects, sitemap quality, broken links, image sizes, security headers, analytics, and form delivery.

**Improve it by:**
- Using clean URLs and 301 redirects from every old path.
- Writing unique titles and meta descriptions.
- Adding Open Graph images and structured organization/article data.
- Optimizing images and fonts, minimizing scripts, and monitoring Core Web Vitals.
- Adding privacy-respecting analytics and conversion tracking.

## Recommended information architecture

```text
Home
About
  Family story
  Mission & values
Our Work
  Bear's Angels
  Literacy & creativity
  Community response
Partners
News & Stories
Contact
Donate
```

## Recommended homepage order

1. Hero: mission, human image, Explore Our Work, Donate.
2. Three program areas.
3. Featured Bear's Angels story.
4. Literacy resource feature.
5. Impact or partner proof.
6. Family story.
7. Three recent stories.
8. Final donation/contact call to action.

## Suggested pitch framing

“The current site contains years of meaningful work, but the presentation makes that work harder to understand and support. The redesign does not change the foundation's identity; it clarifies it. Visitors can understand the mission immediately, see where the money and effort go, find current partners, and take action with confidence.”

## Sources reviewed

- Homepage: https://www.tortorellafoundation.org/
- About: https://www.tortorellafoundation.org/about/
- Bear's Angels: https://www.tortorellafoundation.org/about-bears-angels/
- News & Events: https://www.tortorellafoundation.org/category/news-and-events/
- Organizations: https://www.tortorellafoundation.org/animal-welfare-organizations-online-links/
- Contact: https://www.tortorellafoundation.org/contact-2/
